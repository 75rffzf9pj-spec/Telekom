import os
from contextlib import asynccontextmanager
from datetime import datetime
from fastapi import FastAPI, Request, Depends, HTTPException
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.responses import HTMLResponse, RedirectResponse
import secrets
from fastapi.templating import Jinja2Templates
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from .storage import init_db, latest_products, latest_check, save_snapshot, record_failure
from .scraper import fetch_products
from .notifier import notify_changes

templates = Jinja2Templates(directory="app/templates")
scheduler = BackgroundScheduler(timezone="Europe/Budapest")

def run_check():
    try:
        products = fetch_products()
        changes = save_snapshot(products)
        if changes:
            notify_changes(changes)
    except Exception as exc:
        record_failure(str(exc))

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    scheduler.add_job(run_check, IntervalTrigger(hours=1), id="telekom-check", replace_existing=True,
                      next_run_time=datetime.now())
    scheduler.start()
    yield
    scheduler.shutdown(wait=False)

app = FastAPI(title="Telekom Refurbished Monitor", lifespan=lifespan)
security = HTTPBasic()

def require_login(credentials: HTTPBasicCredentials = Depends(security)):
    expected_user = os.getenv("DASHBOARD_USER", "")
    expected_password = os.getenv("DASHBOARD_PASSWORD", "")
    if not expected_user or not expected_password:
        raise HTTPException(status_code=503, detail="Állítsd be a DASHBOARD_USER és DASHBOARD_PASSWORD értékeket a .env fájlban.")
    valid_user = secrets.compare_digest(credentials.username, expected_user)
    valid_password = secrets.compare_digest(credentials.password, expected_password)
    if not (valid_user and valid_password):
        raise HTTPException(status_code=401, detail="Hibás belépési adatok.", headers={"WWW-Authenticate": "Basic"})
    return credentials

@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, _: HTTPBasicCredentials = Depends(require_login)):
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "products": latest_products(),
        "check": latest_check(),
        "telegram_enabled": bool(os.getenv("TELEGRAM_BOT_TOKEN") and os.getenv("TELEGRAM_CHAT_ID")),
    })

@app.post("/check")
def check_now(_: HTTPBasicCredentials = Depends(require_login)):
    run_check()
    return RedirectResponse("/", status_code=303)

@app.get("/health")
def health():
    return {"status":"ok", "last_check":latest_check()}
