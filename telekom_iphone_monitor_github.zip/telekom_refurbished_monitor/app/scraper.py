import re
from urllib.parse import urljoin
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

SOURCE_URL = "https://www.telekom.hu/webshop/keszulekek/mobiltelefonok?brand=Apple&stockForWeb=W01&productType=refurbished"
MODELS = ("iPhone 15 Pro", "iPhone 16 Pro", "iPhone 17 Pro")
PRICE_RE = re.compile(r"(?<!\d)(\d{1,3}(?:[ .\u00a0]\d{3})+|\d{5,6})\s*Ft", re.I)
STORAGE_RE = re.compile(r"\b(128|256|512|1024|1)\s*(GB|TB)\b", re.I)

def _normalise_price(raw: str) -> int:
    return int(re.sub(r"\D", "", raw))

def _extract_storage(text: str, href: str) -> str:
    match = STORAGE_RE.search(text) or STORAGE_RE.search(href.replace("-", " "))
    if not match:
        return "Tárhely nincs megadva"
    amount, unit = match.groups()
    if amount == "1" and unit.upper() == "TB":
        return "1 TB"
    return f"{amount} {unit.upper()}"

def _best_card_text(anchor):
    # Telekom card markup can change. Walk up a few ancestors and select the
    # smallest useful container containing the model and at least one price.
    candidates = []
    for level in range(1, 7):
        try:
            node = anchor.locator(f"xpath=..{'/..' * (level-1)}")
            txt = " ".join(node.inner_text(timeout=1200).split())
            if txt and len(txt) < 1800 and any(m in txt for m in MODELS) and PRICE_RE.search(txt):
                candidates.append(txt)
        except Exception:
            continue
    return min(candidates, key=len) if candidates else " ".join(anchor.inner_text().split())

def fetch_products():
    """Read refurbished products currently shown by Telekom's online-stock filter."""
    found = {}
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, args=["--no-sandbox"])
        page = browser.new_page(
            locale="hu-HU",
            user_agent="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/124 Safari/537.36",
            viewport={"width": 1440, "height": 1100},
        )
        response = page.goto(SOURCE_URL, wait_until="domcontentloaded", timeout=60000)
        try:
            page.wait_for_load_state("networkidle", timeout=18000)
        except PlaywrightTimeoutError:
            pass
        page.wait_for_timeout(3500)
        # Lazy-loaded product grids: scroll in small increments.
        for _ in range(6):
            page.mouse.wheel(0, 900)
            page.wait_for_timeout(500)

        anchors = page.locator("a[href]")
        count = min(anchors.count(), 2500)
        for i in range(count):
            a = anchors.nth(i)
            try:
                href = a.get_attribute("href") or ""
                label = " ".join(a.inner_text(timeout=700).split())
                if not href or not ("iphone" in href.lower() or any(model in label for model in MODELS)):
                    continue
                card_text = _best_card_text(a)
                if not any(model in card_text or model in label for model in MODELS):
                    continue
                model = next((m for m in MODELS if m in card_text or m in label), None)
                if not model:
                    continue
                prices = PRICE_RE.findall(card_text)
                if not prices:
                    continue
                # On product tiles the current price is normally the last visible
                # Ft amount. Keep this explicit so markup can be tuned if Telekom changes.
                price = _normalise_price(prices[-1])
                if price < 50000 or price > 2000000:
                    continue
                full_url = urljoin(SOURCE_URL, href)
                storage = _extract_storage(card_text + " " + label, href)
                key = f"{model}|{storage}|{full_url}"
                found[key] = {
                    "key": key, "model": model, "storage": storage,
                    "price": price, "url": full_url,
                    "available": True, "raw_text": card_text[:1200],
                }
            except Exception:
                continue
        browser.close()

    if not found:
        raise RuntimeError(
            "A Telekom oldal betöltődött, de nem sikerült felismerni a figyelt modellek termékkártyáit. "
            "Lehetséges, hogy megváltozott az oldal felépítése vagy a botvédelem blokkolta a lekérdezést."
        )
    return list(found.values())
