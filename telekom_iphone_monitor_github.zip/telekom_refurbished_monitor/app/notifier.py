import os
import requests

def send_telegram(message: str):
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat_id:
        return False
    response = requests.post(
        f"https://api.telegram.org/bot{token}/sendMessage",
        json={"chat_id": chat_id, "text": message, "disable_web_page_preview": False},
        timeout=20,
    )
    response.raise_for_status()
    return True

def notify_changes(changes):
    for item in changes:
        model = item["model"]
        storage = item["storage"]
        url = item["url"]
        if item["event"] == "price":
            old, new = item["old_price"], item["price"]
            delta = item["change"]
            if delta < 0:
                title = f"ÁRCSÖKKENÉS: {model} {storage}"
                detail = f"Régi ár: {old:,} Ft\\nÚj ár: {new:,} Ft\\nMegtakarítás: {-delta:,} Ft"
            else:
                title = f"ÁREMELKEDÉS: {model} {storage}"
                detail = f"Régi ár: {old:,} Ft\\nÚj ár: {new:,} Ft\\nDrágulás: {delta:,} Ft"
        elif item["event"] == "available":
            title = f"ÚJRA ELÉRHETŐ: {model} {storage}"
            if item.get("old_price") is None:
                detail = f"Első észlelt ár: {item['price']:,} Ft"
            else:
                detail = f"Korábbi ár: {item['old_price']:,} Ft\\nAktuális ár: {item['price']:,} Ft"
                if item.get("change", 0) < 0:
                    detail += f"\\nMegtakarítás: {-item['change']:,} Ft"
        elif item["event"] == "out_of_stock":
            title = f"ELFOGYOTT: {model} {storage}"
            detail = f"Utolsó ismert ár: {item['price']:,} Ft"
        else:
            continue
        send_telegram(f"{title}\\n{detail}\\n{url}")
