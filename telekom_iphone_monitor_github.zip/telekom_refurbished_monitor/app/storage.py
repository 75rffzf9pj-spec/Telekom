import sqlite3
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = Path("data/monitor.db")

def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    with connect() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS products (
            product_key TEXT PRIMARY KEY, model TEXT NOT NULL, storage TEXT NOT NULL,
            price INTEGER NOT NULL, url TEXT NOT NULL, available INTEGER NOT NULL,
            raw_text TEXT, first_seen TEXT NOT NULL, last_seen TEXT NOT NULL
        )""")
        db.execute("""CREATE TABLE IF NOT EXISTS checks (
            id INTEGER PRIMARY KEY AUTOINCREMENT, checked_at TEXT NOT NULL,
            status TEXT NOT NULL, product_count INTEGER NOT NULL DEFAULT 0, message TEXT
        )""")
        db.commit()

def latest_products():
    with connect() as db:
        return [dict(r) for r in db.execute("SELECT * FROM products WHERE available=1 ORDER BY model, storage")]

def history(product_key, limit=24):
    with connect() as db:
        return [dict(r) for r in db.execute(
            "SELECT checked_at, old_price, new_price, change FROM price_history WHERE product_key=? ORDER BY id DESC LIMIT ?",
            (product_key, limit))]

def save_snapshot(products):
    now = datetime.now(timezone.utc).isoformat()
    changes = []
    with connect() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS price_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT, product_key TEXT NOT NULL,
            checked_at TEXT NOT NULL, old_price INTEGER, new_price INTEGER NOT NULL, change INTEGER NOT NULL
        )""")
        old_rows = {r["product_key"]: dict(r) for r in db.execute("SELECT * FROM products")}
        had_successful_snapshot = db.execute("SELECT COUNT(*) FROM checks WHERE status='success'").fetchone()[0] > 0
        current_keys = set()
        for item in products:
            key = item["key"]
            current_keys.add(key)
            old = old_rows.get(key)
            if old:
                delta = item["price"] - old["price"]
                if not old["available"]:
                    changes.append({**item, "old_price": old["price"], "change": delta, "event": "available"})
                if delta != 0:
                    db.execute("INSERT INTO price_history(product_key,checked_at,old_price,new_price,change) VALUES(?,?,?,?,?)",
                               (key, now, old["price"], item["price"], delta))
                    changes.append({**item, "old_price": old["price"], "change": delta, "event": "price"})
                db.execute("""UPDATE products SET model=?,storage=?,price=?,url=?,available=1,raw_text=?,last_seen=? WHERE product_key=?""",
                           (item["model"], item["storage"], item["price"], item["url"], item.get("raw_text",""), now, key))
            else:
                if had_successful_snapshot:
                    changes.append({**item, "old_price": None, "change": 0, "event": "available"})
                db.execute("""INSERT INTO products(product_key,model,storage,price,url,available,raw_text,first_seen,last_seen)
                              VALUES(?,?,?,?,?,1,?,?,?)""",
                           (key,item["model"],item["storage"],item["price"],item["url"],item.get("raw_text",""),now,now))
                # First observation is a baseline, not an assumed price drop.
        # Items absent from the filtered page are marked unavailable, but retained for history.
        for key, old in old_rows.items():
            if key not in current_keys and old["available"]:
                db.execute("UPDATE products SET available=0,last_seen=? WHERE product_key=?", (now,key))
                changes.append({**old, "event":"out_of_stock", "old_price":old["price"], "change":0})
        db.execute("INSERT INTO checks(checked_at,status,product_count,message) VALUES(?,?,?,?)",
                   (now,"success",len(products),None))
        db.commit()
    return changes

def record_failure(message):
    with connect() as db:
        db.execute("INSERT INTO checks(checked_at,status,product_count,message) VALUES(?,?,0,?)",
                   (datetime.now(timezone.utc).isoformat(),"error",message[:1000]))
        db.commit()

def latest_check():
    with connect() as db:
        row = db.execute("SELECT * FROM checks ORDER BY id DESC LIMIT 1").fetchone()
        return dict(row) if row else None
