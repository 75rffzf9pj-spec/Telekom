import json, os
from datetime import datetime, timezone
from pathlib import Path
from app.scraper import fetch_products
from app.notifier import send_telegram

STATE = Path('monitor_state.json')
OUT = Path('site/data.json')

def money(n):
    return f"{n:,}".replace(',', ' ')

def notify(item):
    model, storage, url = item['model'], item['storage'], item['url']
    event = item['event']
    if event == 'price':
        old, new, delta = item['old_price'], item['price'], item['change']
        title = 'ÁRCSÖKKENÉS' if delta < 0 else 'ÁREMELKEDÉS'
        detail = f"Korábbi ár: {money(old)} Ft\nÚj ár: {money(new)} Ft\n" + (f"Megtakarítás: {money(-delta)} Ft" if delta < 0 else f"Drágulás: {money(delta)} Ft")
    elif event == 'available':
        title = 'ÚJ KÉSZLET'
        detail = f"Aktuális ár: {money(item['price'])} Ft"
        if item.get('old_price') is not None:
            detail += f"\nKorábbi ár: {money(item['old_price'])} Ft"
    elif event == 'out_of_stock':
        title = 'ELFOGYOTT'
        detail = f"Utolsó ismert ár: {money(item['price'])} Ft"
    else:
        return
    send_telegram(f"{title}: {model} · {storage}\n{detail}\n{url}")

def main():
    now = datetime.now(timezone.utc).isoformat()
    products = fetch_products()
    old_state = json.loads(STATE.read_text('utf-8')) if STATE.exists() else {'products': {}, 'has_baseline': False}
    old_products = old_state.get('products', {})
    current = {}
    changes = []
    for p in products:
        key = p['key']
        old = old_products.get(key)
        item = {k: p[k] for k in ('key','model','storage','price','url','available')}
        item['previous_price'] = old.get('price') if old else None
        item['price_change'] = p['price'] - old['price'] if old else None
        current[key] = {**item, 'last_seen': now}
        if old:
            if not old.get('available', True):
                changes.append({**p, 'old_price': old['price'], 'change': p['price'] - old['price'], 'event': 'available'})
            if p['price'] != old['price']:
                changes.append({**p, 'old_price': old['price'], 'change': p['price'] - old['price'], 'event': 'price'})
        elif old_state.get('has_baseline'):
            changes.append({**p, 'old_price': None, 'change': 0, 'event': 'available'})
    for key, old in old_products.items():
        if key not in current and old.get('available', True):
            changes.append({**old, 'event': 'out_of_stock'})
    for change in changes:
        notify(change)
    STATE.write_text(json.dumps({'products': current, 'has_baseline': True, 'checked_at': now}, ensure_ascii=False, indent=2), 'utf-8')
    OUT.parent.mkdir(exist_ok=True)
    payload = {
        'checked_at': now,
        'status': 'success',
        'count': len(products),
        'products': sorted(current.values(), key=lambda x: (x['model'], x['storage'])),
        'changes': changes,
    }
    OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), 'utf-8')
    print(f"Sikeres ellenőrzés: {len(products)} termék, {len(changes)} változás")

if __name__ == '__main__':
    main()
