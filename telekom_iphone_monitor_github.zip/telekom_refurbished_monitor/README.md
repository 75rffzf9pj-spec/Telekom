# Telekom iPhone Monitor – ingyenes GitHub-verzió

A GitHub Actions óránként futtatja a Playwright-alapú Telekom-ellenőrzést. A statikus mobilos dashboard GitHub Pages-en jelenik meg. A termék- és árelőzmény a `monitor_state.json` fájlban marad meg.

## Telepítés
1. Hozz létre egy új GitHub-repositoryt `telekom-iphone-monitor` néven. A GitHub Free csomagban a Pages ingyenes használatához legyen **Public**.
2. Töltsd fel a projekt fájljait úgy, hogy a `.github` mappa is felkerüljön. Ne tölts fel `.env` fájlt vagy bot tokent.
3. A repositoryban nyisd meg: **Settings → Pages → Build and deployment → Source → GitHub Actions**.
4. Nyisd meg az **Actions** fület, és engedélyezd a workflow-kat, ha a GitHub kéri.
5. Indítsd el kézzel egyszer: **Actions → Telekom iPhone monitor → Run workflow**.
6. A sikeres futás után a **Settings → Pages** részen megjelenik a weboldal címe.
7. iPhone-on Safariban nyisd meg a címet → Megosztás → **Főképernyőhöz adás**.

## Telegram értesítés (opcionális)
Repository → Settings → Secrets and variables → Actions → New repository secret:
- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`

A token ne kerüljön a forráskódba. Telegramon a @BotFather segítségével hozz létre botot, majd írj neki egy üzenetet.

## Fontos
- Az ütemezett GitHub Actions futás időpontja terhelés miatt késhet.
- A GitHub Actions ingyenes perceinek kerete és a Pages feltételei a GitHub csomagtól függenek.
- A Telekom scraper még nincs élőben validálva, ezért az első futás logját ellenőrizni kell. Ha a Telekom oldalát botvédelem blokkolja vagy megváltozik a HTML, a kinyerést módosítani kell.
- A `stockForWeb=W01` listán megjelenő termékeket tekinti elérhetőnek.
